#!/usr/bin/env bash
# Dev server for the broken Acme site.
cd "$(dirname "$0")" && python3 -m http.server 3000
